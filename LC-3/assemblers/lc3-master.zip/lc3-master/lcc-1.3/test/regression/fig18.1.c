#include <stdio.h>

int main()
{
  char inChar1;
  char inChar2;

  printf("Input character 1:\n");
  inChar1 = getchar();

  printf("Input character 2:\n");
  inChar2 = getchar();

  printf("Character 1 is %c\n", inChar1);
  printf("Character 2 is %c\n", inChar2);
}
