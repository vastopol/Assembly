#include "lc2200/archlc2200.h"
#define ARCHCLASS ArchLC2200
