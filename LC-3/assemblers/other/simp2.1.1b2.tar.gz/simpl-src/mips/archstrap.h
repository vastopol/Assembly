#include "mips/archmips.h"
#define ARCHCLASS ArchMIPS
#define NO_ASSEMBLER // no assembler until asmmain bugs are fixed
