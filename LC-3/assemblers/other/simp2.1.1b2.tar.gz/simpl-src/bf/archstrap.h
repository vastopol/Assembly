#include "bf/allbf.h"
#define ARCHCLASS ArchBF
