#include "lc3/archlc3.h"
#define ARCHCLASS ArchLC3
