This directory is where you will clone your assignments from GitHub.
It is required in this course to use the provided templates.
