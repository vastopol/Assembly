This is the directory that you are going to be using for your virtual machince. Everything inside this directory will be shared with VM.
You can add/delete and modify any file except for the file called Vagrantfile. Once you call vagrant up you will not be allowed to modify that file. This means that you can't move, delete or rename it. This also applies to this directory. So before starting uop your VM for the first time make sure it is located on your computer in a place that you like.

Inside this directory you will notice that there is a directory called CS61. 
In there you will find 2 directories: cs61_assignments and cs61_labs.
That will be were you will clone your assignments and labs templates from GitHub.
It is required in this course to use the provided templates.
